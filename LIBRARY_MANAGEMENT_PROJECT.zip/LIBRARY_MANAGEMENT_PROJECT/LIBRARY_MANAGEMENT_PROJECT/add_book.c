#include "library.h"

void add_new_book(Book **head)
{
    char name[NAME_LEN], author[AUTHOR_LEN];
    int pages;

    read_line("Enter book name: ", name, sizeof(name));
    read_line("Enter author name: ", author, sizeof(author));
    pages = read_int("Enter number of pages: ", 1, 1000000);

    if (book_exists(*head, name, author)) {
        printf("Duplicate book entry. This book by this author is already in the library.\n");
        return;
    }

    Book *new_book = create_book(name, author, pages, 1);
    if (!new_book) {
        printf("Memory allocation failed.\n");
        return;
    }

    if (*head == NULL) {
        *head = new_book;
    } else {
        Book *temp = *head;
        while (temp->next) temp = temp->next;
        temp->next = new_book;
    }

    printf("Book added successfully.\n");
}
