#include "library.h"

void count_book(const Book *head)
{
    char name[NAME_LEN], author[AUTHOR_LEN];
    const Book *temp;

    read_line("Enter book name: ", name, sizeof(name));
    read_line("Enter author name: ", author, sizeof(author));

    temp = head;
    while (temp) {
        if (strcmp(temp->book_name, name) == 0 &&
            strcmp(temp->author_name, author) == 0) {
            printf("Available count: %d\n", temp->available);
            return;
        }
        temp = temp->next;
    }

    printf("Book not found.\n");
}
