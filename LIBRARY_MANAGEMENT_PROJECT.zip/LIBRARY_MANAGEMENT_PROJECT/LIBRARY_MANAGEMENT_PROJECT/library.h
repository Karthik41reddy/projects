#ifndef LIBRARY_H
#define LIBRARY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATA_FILE "books.dat"
#define NAME_LEN 100
#define AUTHOR_LEN 100

typedef enum {
    SUCCESS = 0,
    FAILURE = 1
} Status;

typedef struct Book {
    char book_name[NAME_LEN];
    char author_name[AUTHOR_LEN];
    int pages;
    int available;
    struct Book *next;
} Book;

void add_new_book(Book **head);
void list_books(const Book *head);
void count_book(const Book *head);
void edit_book(Book *head);
void take_book(Book *head);
void find_book(const Book *head);
void save_books(const Book *head);
void load_books(Book **head);
void free_books(Book **head);

Book *create_book(const char *name, const char *author, int pages, int available);
int book_exists(const Book *head, const char *name, const char *author);
Book *find_by_name_and_author(Book *head, const char *name, const char *author);
void read_line(const char *prompt, char *buffer, size_t size);
int read_int(const char *prompt, int min, int max);

#endif
