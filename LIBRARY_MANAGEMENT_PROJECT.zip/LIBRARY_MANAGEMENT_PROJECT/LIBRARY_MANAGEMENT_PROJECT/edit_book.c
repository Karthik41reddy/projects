#include "library.h"

void edit_book(Book *head)
{
    char name[NAME_LEN], author[AUTHOR_LEN];
    char new_value[NAME_LEN];
    int option, value;
    Book *book;

    read_line("Enter current book name: ", name, sizeof(name));
    read_line("Enter current author name: ", author, sizeof(author));

    book = find_by_name_and_author(head, name, author);
    if (!book) {
        printf("Book not found.\n");
        return;
    }

    printf("1. Edit book name\n2. Edit author name\n3. Edit pages\n4. Edit number of books\n");
    option = read_int("Choose option: ", 1, 4);

    switch (option) {
        case 1:
            read_line("Enter new book name: ", new_value, sizeof(new_value));
            if (book_exists(head, new_value, book->author_name) &&
                strcmp(new_value, book->book_name) != 0) {
                printf("Duplicate book entry. Edit cancelled.\n");
                return;
            }
            strncpy(book->book_name, new_value, NAME_LEN - 1);
            book->book_name[NAME_LEN - 1] = '\0';
            break;
        case 2:
            read_line("Enter new author name: ", new_value, sizeof(new_value));
            if (book_exists(head, book->book_name, new_value) &&
                strcmp(new_value, book->author_name) != 0) {
                printf("Duplicate book/author entry. Edit cancelled.\n");
                return;
            }
            strncpy(book->author_name, new_value, AUTHOR_LEN - 1);
            book->author_name[AUTHOR_LEN - 1] = '\0';
            break;
        case 3:
            value = read_int("Enter new number of pages: ", 1, 1000000);
            book->pages = value;
            break;
        case 4:
            value = read_int("Enter new number of books available: ", 0, 1000000);
            book->available = value;
            break;
    }

    printf("Book information updated successfully.\n");
}
