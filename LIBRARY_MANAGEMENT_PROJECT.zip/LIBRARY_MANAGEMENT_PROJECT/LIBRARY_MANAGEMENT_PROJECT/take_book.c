#include "library.h"

void take_book(Book *head)
{
    char name[NAME_LEN], author[AUTHOR_LEN];
    Book *book;

    read_line("Enter book name: ", name, sizeof(name));
    read_line("Enter author name: ", author, sizeof(author));

    book = find_by_name_and_author(head, name, author);
    if (!book) {
        printf("Book not found.\n");
        return;
    }

    if (book->available <= 0) {
        printf("No copies are currently available.\n");
        return;
    }

    book->available--;
    printf("Book issued successfully. Remaining copies: %d\n", book->available);
}
