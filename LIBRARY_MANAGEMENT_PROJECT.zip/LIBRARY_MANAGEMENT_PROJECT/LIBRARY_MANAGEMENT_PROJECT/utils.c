#include "library.h"

Book *create_book(const char *name, const char *author, int pages, int available)
{
    Book *book = (Book *)malloc(sizeof(Book));
    if (!book) return NULL;

    strncpy(book->book_name, name, NAME_LEN - 1);
    book->book_name[NAME_LEN - 1] = '\0';
    strncpy(book->author_name, author, AUTHOR_LEN - 1);
    book->author_name[AUTHOR_LEN - 1] = '\0';
    book->pages = pages;
    book->available = available;
    book->next = NULL;
    return book;
}

int book_exists(const Book *head, const char *name, const char *author)
{
    while (head) {
        if (strcmp(head->book_name, name) == 0 &&
            strcmp(head->author_name, author) == 0)
            return 1;
        head = head->next;
    }
    return 0;
}

Book *find_by_name_and_author(Book *head, const char *name, const char *author)
{
    while (head) {
        if (strcmp(head->book_name, name) == 0 &&
            strcmp(head->author_name, author) == 0)
            return head;
        head = head->next;
    }
    return NULL;
}

void read_line(const char *prompt, char *buffer, size_t size)
{
    int ch;
    printf("%s", prompt);
    if (!fgets(buffer, (int)size, stdin)) {
        buffer[0] = '\0';
        return;
    }

    if (strchr(buffer, '\n')) {
        buffer[strcspn(buffer, "\n")] = '\0';
    } else {
        while ((ch = getchar()) != '\n' && ch != EOF) {}
    }
}

int read_int(const char *prompt, int min, int max)
{
    char buffer[64];
    char *end;
    long value;

    while (1) {
        read_line(prompt, buffer, sizeof(buffer));
        value = strtol(buffer, &end, 10);

        while (*end == ' ' || *end == '\t') end++;

        if (end != buffer && *end == '\0' && value >= min && value <= max)
            return (int)value;

        printf("Invalid input. Enter a number between %d and %d.\n", min, max);
    }
}

void free_books(Book **head)
{
    Book *temp;
    while (*head) {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
}
