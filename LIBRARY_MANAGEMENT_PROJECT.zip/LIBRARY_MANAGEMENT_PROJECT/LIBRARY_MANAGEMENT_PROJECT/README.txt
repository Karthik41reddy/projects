LIBRARY MANAGEMENT - MINI PROJECT
=================================

This project follows the requirements in the supplied Library Management
mini-project PDF.

TECHNOLOGY
----------
Language: C
Data structure: Singly Linked List (SLL)
Storage: Binary file (books.dat)
Build system: Makefile / make

PROJECT FILES
-------------
library.h          Common structure, typedefs, declarations and constants
main.c             Main menu and program loop
add_book.c         Add new book
list_book.c        List available books
count_book.c       Count copies of a selected book
edit_book.c        Edit book information
take_book.c        Take/issue a book
find_book.c        Find by book name or author
file_handling.c    Save/load persistent data
utils.c            Common input, search, allocation and cleanup functions
Makefile           Builds all C source files
README.txt         Usage and build instructions

REQUIREMENTS IMPLEMENTED
-------------------------
1. Add a book with book name, author name and number of pages.
2. Each book also maintains the number of available copies.
3. Duplicate book+author entries are not stored.
4. Different books may have the same author.
5. Multiple authors may have the same book title because uniqueness is
   based on book name + author.
6. List available books with book name, author, pages and available count.
7. Count/display available copies for a specific book.
8. Edit book name, author, pages or available-book count.
9. Take/issue a book by selecting book name and then author.
10. Find by book name or author.
11. Explicit save option.
12. Data is automatically saved when quitting.
13. Old data is loaded when the application starts.
14. Structure pointer + SLL are used.
15. File handling is implemented in a separate source file.
16. Separate source files are used for the main application tasks.
17. User-defined functions are provided for the tasks.
18. typedef and enum are used; all shared definitions are in library.h.

COMPILATION
-----------
Linux / macOS / WSL:
    make

EXECUTION
---------
Linux / macOS / WSL:
    ./library

CLEAN BUILD
-----------
    make clean
    make

WINDOWS
-------
Option 1 (recommended for this Makefile):
Install MSYS2/MinGW and open the MSYS2 terminal in this project folder.
Then run:
    make
    ./library

If 'make' is not available, install the make package through your
MinGW/MSYS2 environment.

DATA FILE
---------
When the program saves data, it creates:
    books.dat

Do not delete books.dat if you want previous records to appear after
relaunching the application.

BASIC TEST
----------
1. Run the program.
2. Select A.
3. Enter:
       Book name: C Programming
       Author: Dennis Ritchie
       Pages: 272
4. Select L to see the available book.
5. Select C and enter the same book/author to see the count.
6. Select F and search by title or author.
7. Select E to edit information.
8. Select T and enter the book name and author to issue one copy.
9. Select S to save explicitly.
10. Select Q.
11. Run ./library again. The previous data should still be present.

NOTES
-----
The PDF's sample menu uses letters a/A, l/L, c/C, e/E, t/T, f/F, s/S
and q/Q. This implementation accepts both upper- and lower-case choices.

The project deliberately uses a singly linked list and structure pointers,
as required by the project version in the supplied document.
