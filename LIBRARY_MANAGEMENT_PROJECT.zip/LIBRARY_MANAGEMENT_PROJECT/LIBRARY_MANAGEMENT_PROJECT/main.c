#include "library.h"

static void print_menu(void)
{
    printf("\n------------------MENU---------------------------\n");
    printf("a/A: Add a new book to library\n");
    printf("l/L: List available books in library\n");
    printf("c/C: Display count of specific book\n");
    printf("e/E: Edit book info\n");
    printf("t/T: Take a book from library\n");
    printf("f/F: Find book in library\n");
    printf("s/S: Save books info in file\n");
    printf("q/Q: Quit from app\n");
    printf("-------------------------------------------------\n");
}

int main(void)
{
    Book *head = NULL;
    char choice[10];

    load_books(&head);
    printf("Library Management System\n");
    printf("Previous data loaded from %s (if available).\n", DATA_FILE);

    while (1) {
        print_menu();
        read_line("Enter choice: ", choice, sizeof(choice));

        switch (choice[0]) {
            case 'a': case 'A': add_new_book(&head); break;
            case 'l': case 'L': list_books(head); break;
            case 'c': case 'C': count_book(head); break;
            case 'e': case 'E': edit_book(head); break;
            case 't': case 'T': take_book(head); break;
            case 'f': case 'F': find_book(head); break;
            case 's': case 'S': save_books(head); break;
            case 'q': case 'Q':
                save_books(head);
                free_books(&head);
                printf("Data saved. Goodbye!\n");
                return 0;
            default:
                printf("Invalid choice. Please select a menu option.\n");
        }
    }
}
