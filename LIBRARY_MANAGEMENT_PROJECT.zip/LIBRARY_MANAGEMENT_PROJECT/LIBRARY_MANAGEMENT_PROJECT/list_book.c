#include "library.h"

void list_books(const Book *head)
{
    const Book *temp = head;
    int found = 0;

    printf("\nAvailable books\n");
    printf("%-30s %-25s %-10s %-10s\n", "Book Name", "Author", "Pages", "Available");
    printf("-------------------------------------------------------------------------------\n");

    while (temp) {
        if (temp->available > 0) {
            printf("%-30s %-25s %-10d %-10d\n",
                   temp->book_name, temp->author_name, temp->pages, temp->available);
            found = 1;
        }
        temp = temp->next;
    }

    if (!found) printf("No available books found.\n");
}
