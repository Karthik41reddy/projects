#include "library.h"

typedef struct {
    char book_name[NAME_LEN];
    char author_name[AUTHOR_LEN];
    int pages;
    int available;
} BookRecord;

void save_books(const Book *head)
{
    FILE *fp;
    const Book *temp;

    fp = fopen(DATA_FILE, "wb");
    if (!fp) {
        perror("Unable to open data file");
        return;
    }

    for (temp = head; temp; temp = temp->next) {
        BookRecord record;
        strncpy(record.book_name, temp->book_name, NAME_LEN);
        strncpy(record.author_name, temp->author_name, AUTHOR_LEN);
        record.pages = temp->pages;
        record.available = temp->available;

        if (fwrite(&record, sizeof(record), 1, fp) != 1) {
            perror("Error while saving book data");
            fclose(fp);
            return;
        }
    }

    fclose(fp);
    printf("Books information saved successfully to %s.\n", DATA_FILE);
}

void load_books(Book **head)
{
    FILE *fp;
    BookRecord record;

    fp = fopen(DATA_FILE, "rb");
    if (!fp) return;

    while (fread(&record, sizeof(record), 1, fp) == 1) {
        Book *new_book = create_book(record.book_name, record.author_name,
                                     record.pages, record.available);
        if (!new_book) {
            printf("Memory allocation failed while loading data.\n");
            fclose(fp);
            return;
        }

        if (*head == NULL) {
            *head = new_book;
        } else {
            Book *temp = *head;
            while (temp->next) temp = temp->next;
            temp->next = new_book;
        }
    }

    fclose(fp);
}
