#include "library.h"

static void find_by_title(const Book *head)
{
    char name[NAME_LEN];
    const Book *temp;
    int found = 0;

    read_line("Enter book name: ", name, sizeof(name));
    for (temp = head; temp; temp = temp->next) {
        if (strcmp(temp->book_name, name) == 0) {
            printf("Book: %s | Author: %s | Pages: %d | Available: %d\n",
                   temp->book_name, temp->author_name, temp->pages, temp->available);
            found = 1;
        }
    }
    if (!found) printf("No book found with that name.\n");
}

static void find_by_author(const Book *head)
{
    char author[AUTHOR_LEN];
    const Book *temp;
    int found = 0;

    read_line("Enter author name: ", author, sizeof(author));
    for (temp = head; temp; temp = temp->next) {
        if (strcmp(temp->author_name, author) == 0) {
            printf("Book: %s | Author: %s | Pages: %d | Available: %d\n",
                   temp->book_name, temp->author_name, temp->pages, temp->available);
            found = 1;
        }
    }
    if (!found) printf("No books found for that author.\n");
}

void find_book(const Book *head)
{
    int option;
    printf("1) Based on book name\n");
    printf("2) Based on author\n");
    option = read_int("Choose search option: ", 1, 2);

    if (option == 1) find_by_title(head);
    else find_by_author(head);
}
